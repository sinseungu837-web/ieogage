이어가게 A0 포스터 사용 안내

1. 인쇄
- output/ieogage_A0_print.pdf를 인쇄용으로 사용하세요.
- A0 세로형 841 × 1189 mm, 1페이지입니다.
- 실제 크기(100%)로 인쇄하면 됩니다. 한글 글꼴이 PDF에 포함되어 있습니다.
- 글자·도형·구조도는 벡터이며, 상단 일러스트와 QR은 이미지입니다.

2. 편집
- output/ieogage_A0_editable.pptx를 PowerPoint에서 여세요.
- 먼저 assets 폴더의 글꼴 3종(NotoSansKR-Regular, SemiBold, ExtraBold)을 설치하면 디자인을 유지할 수 있습니다.
- 글자·도형·구조도는 각각 편집할 수 있습니다. 상단 일러스트와 로고는 이미지입니다.
- 편집 후 PDF로 내보내 인쇄하세요. PowerPoint는 A0 사용자 지정 크기로 설정되어 있습니다.
- assets/OFL.txt에 글꼴 라이선스를 함께 제공합니다.

3. 의도적으로 비워 둔 부분
- 점주 인터뷰·고객 검증의 대상/인원, 기간, 주요 결과
- 팀명, 팀원
- 시연 영상 QR: 하단 오른쪽 흰 사각형에 최종 영상 QR 이미지를 넣으세요.
- 실제 인터뷰 인원·만족도·시간 절감률·수익 증가율은 임의로 작성하지 않았습니다.

4. QR
- GitHub: https://github.com/sinseungu837-web/ieogage
- 서비스 체험: https://ieogage.streamlit.app
- 시연 영상: 빈칸
- GitHub와 서비스 QR은 인식 결과를 검증했습니다. PDF에서는 QR을 클릭해도 해당 주소가 열립니다.

5. 콘텐츠 기준
- 현재 구현: 사진 업로드/촬영, Gemini 물품 인식, 사용자 박스/표 수정, 팀 조사 시세표·연식 기반 참고 견적, CSV 내려받기, Kakao Local API 기반 주변 업체 확인.
- 개선 기록은 대화와 개발 기록에서 확인된 사용성 피드백을 정리한 것입니다. 외부 점주 인터뷰 결과는 별도 빈칸으로 구분했습니다.
- 상단은 물품 순환을 표현한 AI 생성 콘셉트 일러스트입니다. 기능 카드도 이용 흐름을 설명하는 도식이며 실제 서비스 화면 캡처는 아닙니다.
- 기대 효과는 기대 사항이며, 실측된 성과 수치가 아닙니다.

6. 재생성(개발자용)
- Python 패키지: reportlab, python-pptx, Pillow, qrcode
- build_poster.py와 assets 폴더가 같은 디렉터리에 있어야 합니다.
- python build_poster.py를 실행하면 인쇄 PDF와 편집용 PPTX가 output 폴더에 생성됩니다.


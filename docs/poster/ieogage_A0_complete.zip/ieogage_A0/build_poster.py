"""이어가게 A0 poster: shared vector layout for print PDF and editable PPTX."""
from pathlib import Path
import sys, math, zipfile
sys.path.insert(0, str(Path(__file__).parent / 'vendor'))
import qrcode
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from pptx import Presentation
from pptx.util import Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn

ROOT = Path(__file__).parent
A = ROOT/'assets'
OUT = ROOT/'output'
OUT.mkdir(exist_ok=True)
W, H = 1682, 2378
S = 841/25.4*72/W
EMU = S*12700
INK = '#20221F'
MUTED = '#656B68'
LIGHT = '#F5F5F5'
LINE = '#DDE0DC'
ORANGE = '#EF6B42'
PEACH = '#FFE4CC'
PALE = '#FFF9F2'
WHITE = '#FFFFFF'

for name,file in [('R','Regular'),('S','SemiBold'),('B','ExtraBold')]:
    pdfmetrics.registerFont(TTFont(name, str(A/f'NotoSansKR-{file}.ttf')))

pdf = canvas.Canvas(str(OUT/'ieogage_A0_print.pdf'), pagesize=(W*S,H*S))
pdf.setTitle('이어가게 | A0 서비스 포스터')
pdf.setAuthor('이어가게')
pdf.setSubject('매장 사진 기반 물품 정리 · 참고 견적 · 판매처 확인')
pdf.setCreator('Editable vector poster / A0 841 × 1189 mm')
prs = Presentation()
prs.slide_width = Emu(W*EMU)
prs.slide_height = Emu(H*EMU)
slide = prs.slides.add_slide(prs.slide_layouts[6])
slide.background.fill.solid()
slide.background.fill.fore_color.rgb = RGBColor.from_string('FFFFFF')
text_boxes = []

def rgb(c): return RGBColor.from_string(c.lstrip('#'))
def no_effect(shape):
    shape._element.spPr.append(OxmlElement('a:effectLst'))
    style=shape._element.find(qn('p:style'))
    if style is not None:
        effect=style.find(qn('a:effectRef'))
        if effect is not None:effect.set('idx','0')

def rect(x,y,w,h,fill=None,stroke=None,r=0,lw=1,dash=False):
    pdf.setLineWidth(lw*S)
    if fill: pdf.setFillColor(HexColor(fill))
    if stroke: pdf.setStrokeColor(HexColor(stroke))
    pdf.setDash([5*S,5*S] if dash else [])
    if r: pdf.roundRect(x*S,(H-y-h)*S,w*S,h*S,r*S,stroke=int(bool(stroke)),fill=int(bool(fill)))
    else: pdf.rect(x*S,(H-y-h)*S,w*S,h*S,stroke=int(bool(stroke)),fill=int(bool(fill)))
    pdf.setDash([])
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE,
        Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    if r:
        try: shp.adjustments[0] = min(r/min(w,h),.5)
        except Exception: pass
    if fill: shp.fill.solid(); shp.fill.fore_color.rgb=rgb(fill)
    else: shp.fill.background()
    if stroke:
        shp.line.color.rgb=rgb(stroke);shp.line.width=Pt(lw*S)
        if dash: shp.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    else: shp.line.fill.background()
    no_effect(shp)
    return shp

def line(x1,y1,x2,y2,color=LINE,lw=1,dash=False):
    pdf.setStrokeColor(HexColor(color));pdf.setLineWidth(lw*S)
    pdf.setDash([5*S,5*S] if dash else [])
    pdf.line(x1*S,(H-y1)*S,x2*S,(H-y2)*S);pdf.setDash([])
    shp=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Emu(x1*EMU),Emu(y1*EMU),Emu(x2*EMU),Emu(y2*EMU))
    shp.line.color.rgb=rgb(color);shp.line.width=Pt(lw*S)
    if dash: shp.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    no_effect(shp)

def circle(x,y,d,fill,stroke=None,lw=1):
    pdf.setFillColor(HexColor(fill))
    if stroke:pdf.setStrokeColor(HexColor(stroke));pdf.setLineWidth(lw*S)
    pdf.circle((x+d/2)*S,(H-y-d/2)*S,d/2*S,stroke=int(bool(stroke)),fill=1)
    shp=slide.shapes.add_shape(MSO_SHAPE.OVAL,Emu(x*EMU),Emu(y*EMU),Emu(d*EMU),Emu(d*EMU))
    shp.fill.solid();shp.fill.fore_color.rgb=rgb(fill)
    if stroke:shp.line.color.rgb=rgb(stroke);shp.line.width=Pt(lw*S)
    else:shp.line.fill.background()
    no_effect(shp)

def text(x,y,string,size=24,font='R',color=INK,w=None,leading=1.42,align='left'):
    rows=string.split('\n')
    widths=[pdfmetrics.stringWidth(row,font,size) for row in rows]
    if w is None:w=max(widths)+4
    if max(widths,default=0)>w+.5:
        raise ValueError(f'Text exceeds box: {string}: {max(widths)} > {w}')
    h=size*leading*len(rows)+size*.15
    text_boxes.append((x,y,w,h,string))
    if x<0 or y<0 or x+w>W+.1 or y+h>H+.1:raise ValueError(f'Outside poster: {string}')
    pdf.setFillColor(HexColor(color));pdf.setFont(font,size*S)
    for i,row in enumerate(rows):
        xx=x if align=='left' else x+(w-widths[i])/2 if align=='center' else x+w-widths[i]
        pdf.drawString(xx*S,(H-y-size*1.02-i*size*leading)*S,row)
    box=slide.shapes.add_textbox(Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    tf=box.text_frame;tf.clear();tf.word_wrap=False
    tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
    tf.vertical_anchor=MSO_ANCHOR.TOP
    from pptx.enum.text import PP_ALIGN
    for i,row in enumerate(rows):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=row;p.font.name={'R':'Noto Sans KR','S':'Noto Sans KR SemiBold','B':'Noto Sans KR ExtraBold'}[font];p.font.size=Pt(size*S)
        p.font.bold=False;p.font.color.rgb=rgb(color)
        family=p.font.name
        for props in (p._p.get_or_add_pPr().get_or_add_defRPr(),p.runs[0]._r.get_or_add_rPr()):
            props.set('lang','ko-KR')
            for tag in ('a:ea','a:cs'):
                node=props.find(qn(tag))
                if node is None:node=OxmlElement(tag);props.append(node)
                node.set('typeface',family)
        p.line_spacing=Pt(size*S*leading);p.space_before=Pt(0);p.space_after=Pt(0)
        p.alignment={'left':PP_ALIGN.LEFT,'center':PP_ALIGN.CENTER,'right':PP_ALIGN.RIGHT}[align]
    return box

def picture(path,x,y,w,h,crop=None):
    path=str(path)
    if crop:
        iw,ih=Image.open(path).size;l,t,r,b=crop
        sx=w/(r-l);sy=h/(b-t)
        pdf.saveState();p=pdf.beginPath();p.rect(x*S,(H-y-h)*S,w*S,h*S);pdf.clipPath(p,stroke=0)
        pdf.drawImage(path,(x-l*sx)*S,(H-y-h-(ih-b)*sy)*S,iw*sx*S,ih*sy*S,mask='auto')
        pdf.restoreState()
        pic=slide.shapes.add_picture(path,Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
        pic.crop_left=l/iw;pic.crop_top=t/ih;pic.crop_right=1-r/iw;pic.crop_bottom=1-b/ih
    else:
        pdf.drawImage(path,x*S,(H-y-h)*S,w*S,h*S,mask='auto')
        pic=slide.shapes.add_picture(path,Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    return pic

def arrow(x1,y1,x2,y2,color=ORANGE,lw=2):
    line(x1,y1,x2,y2,color,lw)
    a=math.atan2(y2-y1,x2-x1)
    for da in (-.6,.6):line(x2,y2,x2-10*math.cos(a+da),y2-10*math.sin(a+da),color,lw)

def pill(x,y,w,label,fill=LIGHT,color=MUTED,size=18):
    rect(x,y,w,36,fill=fill,r=18)
    text(x,y+5,label,size,'S',color,w=w,align='center')

def section(x,y,kicker,title,width):
    text(x,y,kicker,16,'S',ORANGE,w=width)
    text(x,y+27,title,35,'B',w=width)

def qr(url,path):
    code=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=12,border=4)
    code.add_data(url);code.make(fit=True)
    code.make_image(fill_color='black',back_color='white').save(path)

qr('https://github.com/sinseungu837-web/ieogage',A/'github-qr.png')
qr('https://ieogage.streamlit.app',A/'service-qr.png')

# Brand / hero.
picture(A/'brand-mark.png',80,65,70,56,crop=(478,300,1060,758))
text(168,60,'이어가게',57,'B',w=400)
text(1070,70,'사진에서 목록으로, 목록에서 다음 가게로.',18,'S',MUTED,w=532,align='right')
line(80,148,1602,148,LINE,1.5)
pill(80,181,305,'매장 정리를 돕는 AI 서비스',PEACH,INK,18)
text(80,246,'가게의 끝에서,\n물품의 다음\n시작을 잇다.',82,'B',w=810,leading=1.2)
picture(A/'circular-cafe.png',876,204,726,484)
text(80,569,'매장 사진 한 장으로,\n물품 정리부터 참고 견적과 판매처 확인까지.',26,'R',MUTED,w=775,leading=1.55)
text(1280,686,'물품 순환을 표현한 콘셉트 이미지',14,'R',MUTED,w=322,align='right')

# Problem definition.
line(80,733,1602,733,LINE,1.5)
section(80,766,'01 / PROBLEM','매장 정리, 어디서부터 시작해야 할까요?',1522)
problems=[('무엇을 팔 수 있을까?','물품을 하나씩 확인하고\n목록을 작성하는 번거로움'),
          ('얼마를 받을 수 있을까?','제조사·모델·연식에 따른\n가격 비교의 어려움'),
          ('어디에 팔 수 있을까?','물품에 맞는 주변 매입 업체를\n직접 찾아야 하는 부담')]
for i,(title,body) in enumerate(problems):
    x=80+i*517
    rect(x,865,488,132,fill=LIGHT,r=15)
    text(x+24,883,title,27,'B',w=440)
    text(x+24,931,body,22,'R',MUTED,w=440,leading=1.35)

# Solution and implemented feature journey.
rect(80,1033,1522,71,fill=ORANGE,r=12)
text(106,1048,'사진으로 파악하고, 직접 확인하고, 매각을 준비합니다.',33,'B',WHITE,w=1470)
section(80,1146,'02 / SOLUTION & FEATURES','사진 한 장에서 시작하는 네 단계',1522)
text(1170,1185,'현재 구현 기능 · 이용 흐름 예시',17,'R',MUTED,w=432,align='right')

card_y=1254
card_w=362.5
steps=[('01','사진 입력','사진 업로드 또는\n모바일 카메라 촬영'),
       ('02','확인·수정','박스 추가·삭제와\n물품 정보 직접 수정'),
       ('03','참고 견적','물품별 가격 범위·근거\n최종 목록 CSV 다운로드'),
       ('04','판매처 찾기','지역·물품별 주변 업체\n연락처와 지도 확인')]
for i,(num,title,body) in enumerate(steps):
    x=80+i*(card_w+24)
    rect(x,card_y,card_w,314,fill=WHITE,stroke=LINE,r=14,lw=1.2)
    pill(x+20,card_y+20,46,num,PEACH,INK,18)
    text(x+80,card_y+19,title,28,'B',w=card_w-100)
    text(x+20,card_y+231,body,21,'R',MUTED,w=card_w-40,leading=1.4)
    # Native editable vector illustrations of the interaction, not screenshots.
    if i==0:
        rect(x+20,card_y+80,card_w-40,130,fill=LIGHT,stroke=LINE,r=10,dash=True)
        rect(x+146,card_y+98,68,55,fill=WHITE,stroke=LINE,r=8)
        arrow(x+180,card_y+145,x+180,card_y+111,INK,2.5)
        line(x+161,card_y+146,x+199,card_y+146,INK,2)
        text(x+20,card_y+168,'사진을 올려 주세요',19,'S',MUTED,w=card_w-40,align='center')
    elif i==1:
        rect(x+20,card_y+80,card_w-40,130,fill=LIGHT,r=10)
        rect(x+44,card_y+101,140,86,stroke=ORANGE,lw=2)
        pill(x+43,card_y+92,91,'커피머신',PEACH,INK,14)
        rect(x+207,card_y+110,85,73,stroke='#737F78',lw=2)
        text(x+219,card_y+132,'의자',20,'S',MUTED,w=60)
        for xx,yy in [(x+44,card_y+101),(x+180,card_y+183)]:rect(xx-3,yy-3,7,7,ORANGE)
    elif i==2:
        rect(x+20,card_y+80,card_w-40,130,fill=PEACH,r=10)
        text(x+40,card_y+96,'우리 가게가 이어갈 가치',18,'S',INK,w=card_w-80)
        text(x+40,card_y+130,'참고 가격 범위',27,'B',w=card_w-80)
        rect(x+40,card_y+178,card_w-80,14,fill=PALE,r=5)
    else:
        for j,(l1,l2) in enumerate([('주변 업체','물품 종류에 맞게'),('연락처 · 지도','입력 지역을 기준으로')]):
            rect(x+20,card_y+80+j*67,card_w-40,58,fill=LIGHT,r=9)
            circle(x+36,card_y+97+j*67,19,PEACH)
            text(x+67,card_y+87+j*67,l1,19,'S',w=card_w-95)
            text(x+67,card_y+113+j*67,l2,15,'R',MUTED,w=card_w-95)

# Evidence / architecture.
col_y=1618
section(80,col_y,'03 / VALIDATION & ITERATION','고객 검증과 개선 기록',730)
text(80,1696,'사용성 피드백 → 반영한 개선',20,'S',MUTED,w=730)
improvements=[('놓친 물건 직접 지정','드래그·터치로 영역 추가'),
              ('긴 화면을 단계별로','입력·수정·견적·판매 준비'),
              ('사진과 표 함께 확인','분석 사진 펼치기·접기')]
for i,(a,b) in enumerate(improvements):
    yy=1736+i*48
    text(80,yy,a,21,'R',w=300)
    arrow(373,yy+16,411,yy+16,ORANGE,1.5)
    text(432,yy,b,21,'S',w=378)
    line(80,yy+38,810,yy+38,LINE,1)
rect(80,1899,730,151,fill=LIGHT,r=12)
text(100,1914,'점주 인터뷰·고객 검증 결과',20,'S',w=690)
text(100,1955,'대상·인원',18,'R',MUTED,w=110)
line(216,1980,473,1980,'#B5BBB5',1)
text(500,1955,'기간',18,'R',MUTED,w=50)
line(562,1980,790,1980,'#B5BBB5',1)
text(100,2000,'주요 결과',18,'R',MUTED,w=110)
line(216,2027,790,2027,'#B5BBB5',1)

section(872,col_y,'04 / SYSTEM & TECHNOLOGY','AI 인식 + 코드 기반 가격 계산',730)
text(872,1696,'AI는 물품을 인식하고, 가격은 시세표로 계산합니다.',19,'R',MUTED,w=730)
nodes=[(872,'사진 입력'),(1129,'Gemini 인식'),(1386,'사용자 수정')]
for x,label in nodes:
    rect(x,1742,216,57,fill=LIGHT,stroke=LINE,r=9)
    text(x,1757,label,20,'S',w=216,align='center')
arrow(1096,1770,1120,1770,ORANGE,1.8)
arrow(1352,1770,1377,1770,ORANGE,1.8)
line(1494,1799,1494,1818,ORANGE,1.8)
line(1052,1818,1494,1818,ORANGE,1.8)
arrow(1052,1818,1052,1840,ORANGE,1.8)
arrow(1422,1818,1422,1840,ORANGE,1.8)
for x,title,sub in [(872,'팀 시세표 + 연식','참고 가격 범위 산정'),(1248,'Kakao Local API','지역·물품별 업체 조회')]:
    rect(x,1848,354,80,fill=PEACH,r=10)
    text(x,1859,title,21,'S',w=354,align='center')
    text(x,1895,sub,17,'R',MUTED,w=354,align='center')
text(872,1955,'Python · Streamlit · Gemini API · Pandas · Pillow',18,'S',MUTED,w=730)
text(872,1988,'CSV · Kakao Local API · GitHub · Streamlit Cloud',18,'S',MUTED,w=730)
text(872,2023,'팀 조사 시세 기반 참고값으로, 실제 거래가는 달라질 수 있습니다.',16,'R',MUTED,w=730)

# Expected impact, deliberately no invented metrics.
line(80,2086,1602,2086,LINE,1.5)
text(80,2114,'05 / EXPECTED IMPACT',16,'S',ORANGE,w=1522)
benefits=[('정리 부담 완화','사진 기반 물품 목록 작성 지원'),
          ('매각 판단 지원','참고 가격과 주변 업체 정보 제공'),
          ('물품 재사용 촉진','남은 집기를 다음 사용자에게 연결')]
for i,(title,body) in enumerate(benefits):
    x=80+i*517
    text(x,2151,title,27,'B',w=488)
    text(x,2194,body,20,'R',MUTED,w=488)

# Footer with functional public QR codes and one intentionally blank video slot.
rect(0,2257,W,121,fill=INK)
text(80,2278,'팀명',17,'R','#CDD1CA',w=60)
line(146,2303,466,2303,'#737970',1)
text(80,2325,'팀원',17,'R','#CDD1CA',w=60)
line(146,2350,686,2350,'#737970',1)
text(755,2280,'직접 확인해 보세요',25,'B',WHITE,w=310)
text(755,2327,'코드 · 서비스 · 시연 영상',17,'R','#CDD1CA',w=310)
# QR strip floats above footer so codes remain large enough to scan at print size.
for x,label,path in [(1110,'GitHub',A/'github-qr.png'),(1284,'서비스 체험',A/'service-qr.png'),(1458,'시연 영상',None)]:
    rect(x-7,2240,151,120,fill=INK,r=10)
    if path:
        qr_picture=picture(path,x,2240,100,100)
        url='https://github.com/sinseungu837-web/ieogage' if label=='GitHub' else 'https://ieogage.streamlit.app'
        qr_picture.click_action.hyperlink.address=url
        pdf.linkURL(url,(x*S,(H-2340)*S,(x+100)*S,(H-2240)*S),relative=0)
    else:
        rect(x,2240,100,100,fill=WHITE,stroke='#B8BDB6',lw=1,dash=True)
    text(x-20,2346,label,16,'S',WHITE,w=140,align='center')

pdf.showPage();pdf.save()
prs.core_properties.title='이어가게 A0 서비스 포스터'
prs.core_properties.subject='고객 검증·팀 정보·시연 영상은 직접 입력하는 편집용 포스터'
prs.core_properties.author='이어가게'
slide.notes_slide.notes_text_frame.text=(
    'A0 세로형 841 × 1189 mm. 인쇄에는 함께 제공된 PDF를 사용하세요. '
    '편집 전 fonts 폴더의 Noto Sans KR 글꼴 3종을 설치하면 서체를 유지할 수 있습니다. '
    '빈칸: 점주 인터뷰/검증의 대상·인원·기간·주요 결과, 팀명·팀원, 시연 영상 QR. '
    '상단 이미지는 물품 순환을 표현한 AI 생성 콘셉트 일러스트이며 실제 서비스 화면이 아닙니다. '
    '고객 검증 수치나 가격 성과를 임의로 넣지 않았습니다. '
    'GitHub QR: https://github.com/sinseungu837-web/ieogage / '
    '서비스 QR: https://ieogage.streamlit.app')
prs.save(OUT/'ieogage_A0_editable.pptx')
print(f'Created {OUT}: {len(text_boxes)} editable text boxes, {len(slide.shapes)} shapes')


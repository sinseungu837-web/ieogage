"""이어가게 A0 poster: shared vector layout for print PDF and editable PPTX."""
from pathlib import Path
import sys, math, zipfile
sys.path.insert(0, str(Path(__file__).parent / 'vendor'))
import qrcode
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from pptx import Presentation
from pptx.util import Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn

ROOT = Path(__file__).parent
A = ROOT/'assets'
OUT = ROOT/'output'
OUT.mkdir(exist_ok=True)
W, H = 1682, 2378
S = 841/25.4*72/W
EMU = S*12700
INK = '#20221F'
MUTED = '#656B68'
LIGHT = '#F5F5F5'
LINE = '#DDE0DC'
ORANGE = '#EF6B42'
PEACH = '#FFE4CC'
PALE = '#FFF9F2'
WHITE = '#FFFFFF'

for name,file in [('R','Regular'),('S','SemiBold'),('B','ExtraBold')]:
    pdfmetrics.registerFont(TTFont(name, str(A/f'NotoSansKR-{file}.ttf')))

pdf = canvas.Canvas(str(OUT/'ieogage_A0_v3_print.pdf'), pagesize=(W*S,H*S))
pdf.setTitle('이어가게 | A0 서비스 포스터')
pdf.setAuthor('이어가게')
pdf.setSubject('매장 사진 기반 물품 정리 · 참고 견적 · 판매처 확인')
pdf.setCreator('Editable vector poster / A0 841 × 1189 mm')
prs = Presentation()
prs.slide_width = Emu(W*EMU)
prs.slide_height = Emu(H*EMU)
slide = prs.slides.add_slide(prs.slide_layouts[6])
slide.background.fill.solid()
slide.background.fill.fore_color.rgb = RGBColor.from_string('FFFFFF')
text_boxes = []

def rgb(c): return RGBColor.from_string(c.lstrip('#'))
def no_effect(shape):
    shape._element.spPr.append(OxmlElement('a:effectLst'))
    style=shape._element.find(qn('p:style'))
    if style is not None:
        effect=style.find(qn('a:effectRef'))
        if effect is not None:effect.set('idx','0')

def rect(x,y,w,h,fill=None,stroke=None,r=0,lw=1,dash=False):
    pdf.setLineWidth(lw*S)
    if fill: pdf.setFillColor(HexColor(fill))
    if stroke: pdf.setStrokeColor(HexColor(stroke))
    pdf.setDash([5*S,5*S] if dash else [])
    if r: pdf.roundRect(x*S,(H-y-h)*S,w*S,h*S,r*S,stroke=int(bool(stroke)),fill=int(bool(fill)))
    else: pdf.rect(x*S,(H-y-h)*S,w*S,h*S,stroke=int(bool(stroke)),fill=int(bool(fill)))
    pdf.setDash([])
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE,
        Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    if r:
        try: shp.adjustments[0] = min(r/min(w,h),.5)
        except Exception: pass
    if fill: shp.fill.solid(); shp.fill.fore_color.rgb=rgb(fill)
    else: shp.fill.background()
    if stroke:
        shp.line.color.rgb=rgb(stroke);shp.line.width=Pt(lw*S)
        if dash: shp.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    else: shp.line.fill.background()
    no_effect(shp)
    return shp

def line(x1,y1,x2,y2,color=LINE,lw=1,dash=False):
    pdf.setStrokeColor(HexColor(color));pdf.setLineWidth(lw*S)
    pdf.setDash([5*S,5*S] if dash else [])
    pdf.line(x1*S,(H-y1)*S,x2*S,(H-y2)*S);pdf.setDash([])
    shp=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Emu(x1*EMU),Emu(y1*EMU),Emu(x2*EMU),Emu(y2*EMU))
    shp.line.color.rgb=rgb(color);shp.line.width=Pt(lw*S)
    if dash: shp.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    no_effect(shp)

def circle(x,y,d,fill,stroke=None,lw=1):
    pdf.setFillColor(HexColor(fill))
    if stroke:pdf.setStrokeColor(HexColor(stroke));pdf.setLineWidth(lw*S)
    pdf.circle((x+d/2)*S,(H-y-d/2)*S,d/2*S,stroke=int(bool(stroke)),fill=1)
    shp=slide.shapes.add_shape(MSO_SHAPE.OVAL,Emu(x*EMU),Emu(y*EMU),Emu(d*EMU),Emu(d*EMU))
    shp.fill.solid();shp.fill.fore_color.rgb=rgb(fill)
    if stroke:shp.line.color.rgb=rgb(stroke);shp.line.width=Pt(lw*S)
    else:shp.line.fill.background()
    no_effect(shp)

def text(x,y,string,size=24,font='R',color=INK,w=None,leading=1.42,align='left'):
    rows=string.split('\n')
    widths=[pdfmetrics.stringWidth(row,font,size) for row in rows]
    if w is None:w=max(widths)+4
    if max(widths,default=0)>w+.5:
        raise ValueError(f'Text exceeds box: {string}: {max(widths)} > {w}')
    h=size*leading*len(rows)+size*.15
    text_boxes.append((x,y,w,h,string))
    if x<0 or y<0 or x+w>W+.1 or y+h>H+.1:raise ValueError(f'Outside poster: {string}')
    pdf.setFillColor(HexColor(color));pdf.setFont(font,size*S)
    for i,row in enumerate(rows):
        xx=x if align=='left' else x+(w-widths[i])/2 if align=='center' else x+w-widths[i]
        pdf.drawString(xx*S,(H-y-size*1.02-i*size*leading)*S,row)
    box=slide.shapes.add_textbox(Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    tf=box.text_frame;tf.clear();tf.word_wrap=False
    tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
    tf.vertical_anchor=MSO_ANCHOR.TOP
    from pptx.enum.text import PP_ALIGN
    for i,row in enumerate(rows):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=row;p.font.name={'R':'Noto Sans KR','S':'Noto Sans KR SemiBold','B':'Noto Sans KR ExtraBold'}[font];p.font.size=Pt(size*S)
        p.font.bold=False;p.font.color.rgb=rgb(color)
        family=p.font.name
        for props in (p._p.get_or_add_pPr().get_or_add_defRPr(),p.runs[0]._r.get_or_add_rPr()):
            props.set('lang','ko-KR')
            for tag in ('a:ea','a:cs'):
                node=props.find(qn(tag))
                if node is None:node=OxmlElement(tag);props.append(node)
                node.set('typeface',family)
        p.line_spacing=Pt(size*S*leading);p.space_before=Pt(0);p.space_after=Pt(0)
        p.alignment={'left':PP_ALIGN.LEFT,'center':PP_ALIGN.CENTER,'right':PP_ALIGN.RIGHT}[align]
    return box

def picture(path,x,y,w,h,crop=None):
    path=str(path)
    if crop:
        iw,ih=Image.open(path).size;l,t,r,b=crop
        sx=w/(r-l);sy=h/(b-t)
        pdf.saveState();p=pdf.beginPath();p.rect(x*S,(H-y-h)*S,w*S,h*S);pdf.clipPath(p,stroke=0)
        pdf.drawImage(path,(x-l*sx)*S,(H-y-h-(ih-b)*sy)*S,iw*sx*S,ih*sy*S,mask='auto')
        pdf.restoreState()
        pic=slide.shapes.add_picture(path,Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
        pic.crop_left=l/iw;pic.crop_top=t/ih;pic.crop_right=1-r/iw;pic.crop_bottom=1-b/ih
    else:
        pdf.drawImage(path,x*S,(H-y-h)*S,w*S,h*S,mask='auto')
        pic=slide.shapes.add_picture(path,Emu(x*EMU),Emu(y*EMU),Emu(w*EMU),Emu(h*EMU))
    return pic

def arrow(x1,y1,x2,y2,color=ORANGE,lw=2):
    line(x1,y1,x2,y2,color,lw)
    a=math.atan2(y2-y1,x2-x1)
    for da in (-.6,.6):line(x2,y2,x2-10*math.cos(a+da),y2-10*math.sin(a+da),color,lw)

def pill(x,y,w,label,fill=LIGHT,color=MUTED,size=18):
    rect(x,y,w,36,fill=fill,r=18)
    text(x,y+5,label,size,'S',color,w=w,align='center')

def section(x,y,kicker,title,width):
    text(x,y,kicker,18,'S',ORANGE,w=width)
    text(x,y+31,title,40,'B',w=width)

def qr(url,path):
    code=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=12,border=4)
    code.add_data(url);code.make(fit=True)
    code.make_image(fill_color='black',back_color='white').save(path)

qr('https://github.com/sinseungu837-web/ieogage',A/'github-qr.png')
qr('https://ieogage.streamlit.app',A/'service-qr.png')

def image_stack(files,x,y,w,h,gap=10):
    """Fit real UI captures as a document layout, preserving their proportions."""
    entries=[(f,None) if isinstance(f,str) else f for f in files]
    dims=[Image.open(A/f).size if crop is None else (crop[2]-crop[0],crop[3]-crop[1]) for f,crop in entries]
    heights=[ih*w/iw for iw,ih in dims]
    scale=min(1,(h-gap*(len(files)-1))/sum(heights))
    ww=w*scale
    yy=y+(h-(sum(heights)*scale+gap*(len(files)-1)))/2
    for (f,crop),hh in zip(entries,heights):
        picture(A/f,x+(w-ww)/2,yy,ww,hh*scale,crop=crop)
        yy+=hh*scale+gap

# Hero: keep the brand and illustration, remove both circled phrases.
picture(A/'brand-mark.png',80,58,64,51,crop=(478,300,1060,758))
text(162,52,'이어가게',53,'B',w=400)
line(80,131,1602,131,LINE,1.5)
pill(80,161,305,'매장 정리를 돕는 AI 서비스',PEACH,INK,18)
text(80,217,'가게의 끝에서,\n물품의 다음\n시작을 잇다.',65,'B',w=850,leading=1.16)
text(80,466,'매장 사진 한 장으로,\n물품 정리부터 참고 견적과 판매처 확인까지.',25,'R',MUTED,w=850,leading=1.5)
picture(A/'circular-cafe.png',895,158,599,399.33)
line(80,575,1602,575,LINE,1.5)

# Problem and value proposition.
section(80,598,'01 / PROBLEM','매장 정리, 어디서부터 시작해야 할까요?',1522)
problems=[('무엇을 팔 수 있을까?','물품을 하나씩 확인하고\n목록을 작성하는 번거로움'),
          ('얼마를 받을 수 있을까?','제조사·모델·연식에 따른\n가격 비교의 어려움'),
          ('어디에 팔 수 있을까?','물품에 맞는 주변 매입 업체를\n직접 찾아야 하는 부담')]
for i,(title,body) in enumerate(problems):
    x=80+i*517
    rect(x,704,488,120,fill=LIGHT,r=15)
    text(x+23,716,title,28,'B',w=442)
    text(x+23,760,body,23,'R',MUTED,w=442,leading=1.25)
rect(80,847,1522,64,fill=ORANGE,r=12)
text(107,861,'매장 사진 한 장으로 물품을 파악하고, 예상 중고 시세와 판매 경로까지 확인하세요.',32,'B',WHITE,w=1468)

# Product snapshots leave more room for the measured validation results.
section(80,933,'02 / SERVICE FLOW','사진 한 장에서 시작하는 네 단계',1522)
text(1030,978,'실제 서비스 UI · 시연용 사진·입력 예시',18,'R',MUTED,w=572,align='right')
card_y=1035
card_w=362.5
steps=[('01','사진 입력','업로드·카메라 촬영으로\n매장 사진 준비',('ui-photo.png',)),
       ('02','확인·수정','박스 추가·삭제와\n물품명·수량·연식 수정',('ui-boxes.png',('ui-table-detail.png',(0,0,1104,195)))),
       ('03','참고 견적','',('ui-estimate.jpg','ui-ground-toggle.jpg')),
       ('04','판매처 찾기','매장 위치와 물품에 맞는\n주변 업체·연락처 확인',('ui-location.png','ui-sale-card.png'))]
for i,(num,title,body,files) in enumerate(steps):
    x=80+i*(card_w+24)
    rect(x,card_y,card_w,390,fill=WHITE,stroke=LINE,r=14,lw=1.2)
    pill(x+20,card_y+18,46,num,PEACH,INK,18)
    text(x+80,card_y+17,title,30,'B',w=card_w-100)
    rect(x+19,card_y+72,card_w-38,220,fill=WHITE,stroke=LINE,r=8,lw=.8)
    image_stack(files,x+25,card_y+79,card_w-50,206,gap=10)
    if i==2:
        text(x+20,card_y+310,'예시 범위 · 가격 산정 근거 제공',21,'R',MUTED,w=card_w-40)
        text(x+20,card_y+346,'13,720,000~16,580,000원',25,'S',w=card_w-40)
    else:
        text(x+20,card_y+310,body,23,'R',MUTED,w=card_w-40,leading=1.45)

# User-provided comparison study: report gains and the unchanged trust score.
section(80,1450,'03 / USER VALIDATION','고객 검증과 개선 기록',1522)
text(1000,1495,'초기 사용성 검증 · 사용자 비교 실험',19,'S',MUTED,w=602,align='right')
text(80,1546,'총 10명 응답 분석  |  A: 기존 수작업  ·  B: 이어가게 활용  |  점수 지표: 5점 척도',23,'R',MUTED,w=1522)

cy=1598; ch=238
for x in (80,597,1114):rect(x,cy,488,ch,fill=PEACH if x==80 else LIGHT,r=14)

# Work efficiency: mean time, same observation in both order groups.
text(104,1612,'작업 효율성',27,'B',w=440)
text(104,1654,'견적 산출 평균 소요 시간 (A → B)',21,'R',MUTED,w=440)
text(104,1691,'7분 10초 → 3분 18초',33,'B',w=440)
text(104,1745,'약 54.0% 감소',34,'B',ORANGE,w=440)
text(104,1802,'순서를 달리한 두 집단 모두 평균 시간 감소',19,'R',MUTED,w=440)

def score_table(x,title,rows,trust=False):
    text(x+24,1612,title,27,'B',w=440)
    text(x+24,1656,'평가 항목',20,'S',MUTED,w=275)
    text(x+310,1656,'A → B',20,'S',MUTED,w=154,align='right')
    for i,(label,value) in enumerate(rows):
        yy=1692+i*42
        if trust and i==2:rect(x+14,yy-4,460,37,fill=PALE,r=7)
        text(x+24,yy,label,23,'R',w=280)
        text(x+310,yy,value,24,'B',MUTED if trust and i==2 else INK,w=154,align='right')
    if trust:text(x+24,1810,'산정 근거의 신뢰성은 추가 개선 과제',18,'S',ORANGE,w=440)

score_table(597,'사용자 부담 완화',[
    ('과정의 쉬움','2.4 → 4.7'),
    ('정신적 부담이 적음','2.2 → 4.0'),
    ('전반적 만족도','2.5 → 4.0')])
score_table(1114,'가격 정보 활용성',[
    ('물품별 가격 파악','2.5 → 4.0'),
    ('전체 매각금액 파악','2.6 → 4.1'),
    ('가격 신뢰도 (동일)','2.8 → 2.8')],trust=True)

rect(80,1855,1522,45,fill=LIGHT,r=9)
text(100,1863,'개선 연결   가격 산정 근거 제시·신뢰성 보강  /  매장 위치를 반영한 판매처 추천',23,'S',MUTED,w=1482)

# Architecture and unchanged, concrete expected impact.
section(80,1924,'04 / SYSTEM & TECHNOLOGY','시스템 구조도 및 기술 스택',730)
nodes=[(80,'사진 입력'),(337,'Gemini 인식'),(594,'사용자 수정')]
for x,label in nodes:
    rect(x,2030,216,47,fill=LIGHT,stroke=LINE,r=8)
    text(x,2041,label,21,'S',w=216,align='center')
arrow(304,2053,328,2053,ORANGE,1.8)
arrow(560,2053,585,2053,ORANGE,1.8)
line(702,2077,702,2100,ORANGE,1.8)
line(257,2100,702,2100,ORANGE,1.8)
arrow(257,2100,257,2116,ORANGE,1.8)
arrow(631,2100,631,2116,ORANGE,1.8)
rect(80,2124,354,81,fill=PEACH,r=9)
text(80,2136,'실제 시세를 바탕으로 구축한\n중고가 DB + 연식',21,'S',w=354,align='center',leading=1.3)
rect(456,2124,354,81,fill=PEACH,r=9)
text(456,2134,'Kakao Local API',22,'S',w=354,align='center')
text(456,2170,'매장 위치·물품별 판매처',18,'R',MUTED,w=354,align='center')
text(80,2220,'Python · Streamlit · Gemini API · Pandas · CSV',19,'S',MUTED,w=730)
text(80,2249,'Kakao Local API · GitHub · Streamlit Cloud',19,'S',MUTED,w=730)

section(872,1924,'05 / EXPECTED IMPACT','기대 효과',730)
benefits=[('물품 정리 부담 완화','사진 기반 목록 생성과 직접 수정으로 정리 작업 지원'),
          ('가격 판단의 근거 확보','물품별·전체 금액 파악 지원, 가격 신뢰성은 보강 과제'),
          ('판매처 탐색 부담 완화','매장 위치·물품별 주변 업체의 연락처·지도 확인')]
for i,(title,body) in enumerate(benefits):
    yy=2030+i*78
    text(872,yy,title,27,'B',w=730)
    text(872,yy+39,body,22,'R',MUTED,w=730)

# Team and video remain intentionally blank; public QR codes remain functional.
rect(0,2280,W,98,fill=INK)
text(80,2293,'팀명',17,'R','#CDD1CA',w=60)
line(146,2318,466,2318,'#737970',1)
text(80,2336,'팀원',17,'R','#CDD1CA',w=60)
line(146,2361,686,2361,'#737970',1)
text(755,2295,'직접 확인해 보세요',25,'B',WHITE,w=310)
text(755,2341,'코드 · 서비스 · 시연 영상',17,'R','#CDD1CA',w=310)
for x,label,path in [(1110,'GitHub',A/'github-qr.png'),(1284,'서비스 체험',A/'service-qr.png'),(1458,'시연 영상',None)]:
    rect(x-7,2255,151,105,fill=INK,r=10)
    if path:
        qr_picture=picture(path,x,2255,100,100)
        url='https://github.com/sinseungu837-web/ieogage' if label=='GitHub' else 'https://ieogage.streamlit.app'
        qr_picture.click_action.hyperlink.address=url
        pdf.linkURL(url,(x*S,(H-2355)*S,(x+100)*S,(H-2255)*S),relative=0)
    else:rect(x,2255,100,100,fill=WHITE,stroke='#B8BDB6',lw=1,dash=True)
    text(x-20,2354,label,14,'S',WHITE,w=140,align='center')

pdf.showPage();pdf.save()
prs.core_properties.title='이어가게 A0 서비스 포스터 · 사용자 비교 실험 반영본'
prs.core_properties.subject='10명 비교 실험의 작업 효율성·사용자 부담·가격 정보 활용성'
prs.core_properties.author='이어가게'
slide.notes_slide.notes_text_frame.text=(
    'A0 841 × 1189 mm. 글꼴 3종을 설치하면 PowerPoint 편집 시 서체가 유지됩니다. '
    '실험 수치는 사용자가 제공한 요약 결과를 그대로 사용했습니다. 총 10명 응답, A 수작업 / B 이어가게. '
    '평균 시간 7분 10초(430초) → 3분 18초(198초), 감소율 (430-198)/430×100=53.953...%, 소수 첫째 자리 반올림 약 54.0%. '
    '실험 순서를 달리한 두 집단 모두 평균 시간 감소가 관찰되었다는 사용자 설명을 반영했습니다. 집단별 인원·시간을 추가하지 않았습니다. '
    '5점 척도: 과정의 쉬움 2.4→4.7, 정신적 부담이 적음 2.2→4.0, 전반적 만족도 2.5→4.0, '
    '물품별 가격 파악 2.5→4.0, 전체 매각금액 파악 2.6→4.1, 가격 신뢰도 2.8→2.8. '
    '통계적 유의성이나 모집단 일반화 주장을 추가하지 않았습니다. 가격 신뢰도는 동일하며, 산정 근거의 신뢰성 확보를 추가 개선 과제로 표시했습니다. '
    '요청한 상단 오른쪽 문구와 그림 아래 캡션은 삭제했습니다. 그림을 108 레이아웃 단위(54 mm) 왼쪽으로 이동했습니다. '
    '상단은 AI 생성 콘셉트 일러스트이며, 기능 화면은 실제 UI에 시연용 사진·박스·브랜드·모델을 설정해 캡처한 예시입니다. 실제 AI 분석 성능 측정 화면은 아닙니다. '
    '예시 가격은 기존 DB·코드로 계산했으며 실제 거래가는 달라질 수 있습니다. 팀명·팀원과 시연 영상 QR은 빈칸입니다. '
    'GitHub: https://github.com/sinseungu837-web/ieogage / 서비스: https://ieogage.streamlit.app')
prs.save(OUT/'ieogage_A0_v3_editable.pptx')
print(f'Created {OUT}: {len(text_boxes)} editable text boxes, {len(slide.shapes)} shapes')

